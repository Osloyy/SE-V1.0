

const { app, BrowserWindow } = require('electron');

app.on('ready', () => {
  const mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      contentSecurityPolicy: "default-src 'self'; script-src 'self';"
    }
  });

  mainWindow.loadFile('index.html');
});
