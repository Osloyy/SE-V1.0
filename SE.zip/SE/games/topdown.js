

const simpleEngine = new SimpleEngine('gameCanvas');

let player, enemy;
let bullets = [];
let lastBulletTime = 0;
const bulletCoolDown = 300;
let healthBar, healthBar1;

let enemyHealth = 100;

simpleEngine.init = function() {
    player = new Player(simpleEngine.canvas.width / 2, simpleEngine.canvas.height / 2, 20, 20, "blue");
    player.speed = 200;

    healthBar = new GameObject(simpleEngine.canvas.width / 2, simpleEngine.canvas.height / 2, 60, 5, "red");
    healthBar.yBob = 2;
    healthBar.bobSpeed = 2;
    healthBar.hidden = true;

    enemy = new GameObject(200, 200, 20, 20, "green");

    healthBar1 = new GameObject(-100, 0, 60, 5, "red");
    healthBar1.yBob = 2;
    healthBar1.bobSpeed = 2;
    healthBar1.hidden = true;
    simpleEngine.setDynamicFPS(60);
}

simpleEngine.update = function(dt) {
    if (!player.destroy) {
        if (simpleEngine.keys.isDown["a"] && player.x - player.speed * dt > 0) {
            player.x -= player.speed * dt;
        }
        if (simpleEngine.keys.isDown["d"] && player.x + player.w + player.speed * dt < simpleEngine.canvas.width) {
            player.x += player.speed * dt;
        }
        if (simpleEngine.keys.isDown["w"] && player.y - player.speed * dt > 0) {
            player.y -= player.speed * dt;
        }
        if (simpleEngine.keys.isDown["s"] && player.y + player.h + player.speed * dt < simpleEngine.canvas.height) {
            player.y += player.speed * dt;
        }
    
        if (simpleEngine.keys.isDown["M1"]) {
            const currentTime = Date.now();
            
            if (currentTime - lastBulletTime > bulletCoolDown) {
                const newBullet = new Bullet(player.x, player.y, 5, 5, "yellow");
                newBullet.speed = 400;
    
                newBullet.updateRotation(simpleEngine.mouse.x, simpleEngine.mouse.y);
                bullets.push(newBullet);
                lastBulletTime = currentTime;
            }
        }
    }

    bullets.forEach(bullet => {
        bullet.update(dt);
        
        if (bullet.y < 0 || bullet.x < 0 || bullet.x > simpleEngine.canvas.width || bullet.y > simpleEngine.canvas.height) {
            bullet.destroy = true;
        }
        if (simpleEngine.isColliding(bullet, enemy)) {
            
            if (!enemy.destroy) {
                bullet.destroy = true;
                if (simpleEngine.isColliding(bullet, enemy)) {
                    if (enemyHealth > 0) {
                        enemyHealth -= 20;
                        healthBar1.w = (enemyHealth / 100) * 60;
                        healthBar1.hidden = false;
                    } else {
                        enemy.destroy = true;
                    }
                }
            }
        }
        
    });

    bullets = bullets.filter(bullet => !bullet.destroy);

    if (!player.destroy) {
        healthBar.yBob += healthBar.bobSpeed * dt;
        healthBar.x = player.x - 20;
        healthBar.y = player.y - 20 + Math.sin(healthBar.yBob) * 3;
    }
    if (!enemy.destroy) {
        if (simpleEngine.isColliding(player, enemy)) {
            if (healthBar.w > 0) {
                healthBar.w -= 20 * dt;
                healthBar.hidden = false;
            }else {
                 player.destroy = true;
            }
        }
    }
    healthBar1.yBob += healthBar1.bobSpeed * dt;
    healthBar1.x = enemy.x - 20;
    healthBar1.y = enemy.y - 20 + Math.sin(healthBar1.yBob) * 3;
    //simpleEngine.updateFPS(dt);
}

simpleEngine.render = function() {
    simpleEngine.background("black");

    for (const bullet of bullets) {
        if (!bullet.destroy) {
            bullet.render(this.ctx);
        }
    }
    
    if (!enemy.destroy) {
        enemy.render(this.ctx);
        if (!healthBar1.hidden) {
            healthBar1.render(this.ctx);
        }

    }
    if (!player.destroy) {
        player.render(this.ctx);
        if (!healthBar.hidden) {
            healthBar.render(this.ctx);
        }
        
    }
    
}

simpleEngine.run();