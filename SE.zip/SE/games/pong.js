

const simpleEngine = new SimpleEngine("gameCanvas");

let player, ai, ball, text1, text2;
let score1 = 0;
let score2 = 0;
let activeLevel;
let pausetext;

const screenw = simpleEngine.canvas.width;
const screenh = simpleEngine.canvas.height;

simpleEngine.init = function() {

    player = new Player(40, 290, 10, 80, "pink");
    player.speed = 300;
    
    ai = new GameObject(1180, 290, 10, 80, "pink");
    ai.speed = 300;

    ball = new GameObject(screenw / 2 - 5, screenh / 2 - 5, 10, 10, "pink");
    ball.velocityX = (Math.random() > 0.5 ? 1 : -1) * Math.random() * 200;
    ball.velocityY = (Math.random() > 0.5 ? 1 : -1) * Math.random() * 200;

    text1 = new TextObject(200, 100, `Player score: ${score1}`, "20px Arial", "pink");
    text2 = new TextObject(1000, 100, `AI score: ${score2}`, "20px Arial", "pink");

    pausetext = new TextObject(screenw / 2, screenh / 2, 'Paused', "20px Arial", "pink");

    let level1Objects = [player, ai, text1, text2, ball];
    let level2Objects = [player, ai, text1, text2, ball, pausetext];

    simpleEngine.createLevel('level1', 'black', level1Objects);
    simpleEngine.createLevel('level2', 'black', level2Objects);
    
    simpleEngine.setDynamicFPS(60);
}

function ballReset(ball, canvas, speed) {
        ball.x = screenw / 2 - ball.w / 2;
        ball.y = screenh / 2 - ball.h / 2;
        ball.velocityX = (Math.random() > 0.5 ? 1 : -1) * Math.random() * speed;
        ball.velocityY = (Math.random() > 0.5 ? 1 : -1) * Math.random() * speed;
}

simpleEngine.update = function(dt) {
    if (activeLevel === "level1") {
        
        if (simpleEngine.keys.isDown["w"] && player.y - player.speed * dt > 0) {
            player.y -= player.speed * dt;
        }
    
        if (simpleEngine.keys.isDown["s"] && player.y + player.h + player.speed * dt < screenh) {
            player.y += player.speed * dt;
        }

        let targetY = ball.y + ball.h / 2 - ai.h / 2;
        const deadZone = ai.h / 2;
    
        if (ai.y >= targetY - deadZone && ai.y <= targetY + deadZone) {
            targetY = ai.y;
        }
        if (ai.y < targetY) {
            ai.y += ai.speed * dt;
        } else if (ai.y > targetY) {
            ai.y -= ai.speed * dt;
        }
    
        const newballY = ball.y + ball.velocityY * dt;
    
        const maxSpeed = 300;
        const minSpeed = 200;
    
        if (newballY < 0 || newballY + ball.h > screenh) {
            ball.velocityY *= -1;
            ball.velocityY += (Math.random() * 2 - 1) * minSpeed;
        } else {
            if (simpleEngine.isColliding(player, ball)) {
                ball.x = player.x + player.w;
                ball.velocityX *= -1;
            }
            if (simpleEngine.isColliding(ai, ball)) {
                ball.x = ai.x - ai.w;
                ball.velocityX *= -1;
            }
        }
    
        ball.x += ball.velocityX * dt;
        ball.y += ball.velocityY * dt;
    
        ball.velocityX = Math.min(maxSpeed, Math.max(minSpeed, Math.abs(ball.velocityX)) * Math.sign(ball.velocityX));
        ball.velocityY = Math.min(maxSpeed, Math.max(minSpeed, Math.abs(ball.velocityY)) * Math.sign(ball.velocityY));
    
        if (ball.x > screenw) {
            score1 += 1;
            ballReset(ball, simpleEngine.canvas, minSpeed);
            text1.text = `Player score: ${score1}`;
    
        } else if (ball.x + ball.w < 0) {
            score2 += 1;
            ballReset(ball, simpleEngine.canvas, minSpeed);
            text2.text = `AI score: ${score2}`;
        }
    
        if (simpleEngine.keys.isDown["r"]) {
            ballReset(ball, simpleEngine.canvas, minSpeed);
        }
        
    }else if (activeLevel === "level2") {

    }
    
    //simpleEngine.updateFPS(dt);

}

simpleEngine.render = function() {

    if (simpleEngine.keys.isToggle["p"]) {
        activeLevel = "level2";
    } else {
        activeLevel = "level1";
        simpleEngine.background("black");
    }
    
    simpleEngine.switchToLevel(activeLevel);
    
}

simpleEngine.run();