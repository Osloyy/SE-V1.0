

const simpleEngine = new SimpleEngine("gameCanvas");

let player, text1, text2, platform, cloud1, cloud2;

let pimg = new SpriteSheet('assets/player.png', 16, 16, 4, 10);

let gimg = new GameImage('assets/Bluerock.jpg');

let c1img = new GameImage('assets/cloud1.png');
let c2img = new GameImage('assets/cloud2.png');

const screenw = simpleEngine.canvas.width;
const screenh = simpleEngine.canvas.height;

simpleEngine.init = function() {
    player = new Player(100, screenh / 2, 50, 50, pimg.image);

    player.speed = 200;
    player.grav = 700;
    player.verticalVelocity = 0;
    player.jumpHeight = 400;
    player.flipX = true;

    text1 = new TextObject(200, 100, `${text1}`, "15px Arial", "#ceb8e3");
    text2 = new TextObject(200, 100, `${text2}`, "15px Arial", "#ceb8e3");
    platform = new Platform(0, 600, screenw, 150, "#358233");

    cloud1 = new GameObject(50, 50, 200, 200, c1img.image);
    cloud2 = new GameObject(600, 50, 200, 200, c2img.image);

    cloud1.speed = 30;
    cloud1.yBob = 0;
    cloud1.bobSpeed = 1;

    cloud2.speed = 30;
    cloud2.yBob = 0;
    cloud2.bobSpeed = 1;
    simpleEngine.setDynamicFPS(60);
}

simpleEngine.update = function(dt) {
    pimg.update();
    cloud1.x += cloud1.speed * dt;
    cloud2.x += cloud2.speed * dt;
    
    if (cloud1.x > screenw) {
        cloud1.x = -cloud1.w;
    }else if(cloud2.x > screenw) {
        cloud2.x = -cloud2.w;
    }

    cloud1.yBob += cloud1.bobSpeed * dt;
    cloud2.yBob += cloud2.bobSpeed * dt;

    cloud1.y = 50 + Math.sin(cloud1.yBob) * 10;
    cloud2.y = 50 + Math.sin(cloud1.yBob) * 20;

    if (simpleEngine.keys.isDown["a"]) {
        player.x -= player.speed * dt;
        player.flipX = false;
    }else if (simpleEngine.keys.isDown["d"]) {
        player.x += player.speed * dt;
        player.flipX = true;
    }
    
    if (simpleEngine.keys.isDown["Space"] && player.isGrounded) {
        player.verticalVelocity = -player.jumpHeight;
        player.isJumping = true;
    }

    if (simpleEngine.isColliding(player, platform)) {
        player.isJumping = false;
        player.verticalVelocity = 0;
        player.y = platform.y - player.h;
        player.isGrounded = true;
    }else {
        player.isGrounded = false;
    }
    
    player.verticalVelocity += player.grav * dt;
    player.y += player.verticalVelocity * dt;
    

    text1.text = "Player x: " + parseInt(player.x).toFixed(0);
    text1.x = player.x - 60;
    text1.y = player.y - 30;

    text2.text = "Player y: " + parseInt(player.y).toFixed(0);
    text2.x = player.x + 60;
    text2.y = player.y - 30;

    //simpleEngine.updateFPS(dt);

    if (simpleEngine.keys.isDown["M1"]) {
        text1.x = simpleEngine.mouse.x;
        text1.y = simpleEngine.mouse.y;
        
    } else if (simpleEngine.keys.isDown["M2"]) {
        text2.x = simpleEngine.mouse.x;
        text2.y = simpleEngine.mouse.y;
    }
    
}

simpleEngine.render = function() {
    simpleEngine.background("#3567a1");
    
    player.render(this.ctx);
    
    platform.render(this.ctx);

    text1.render(this.ctx);
    
    text2.render(this.ctx);

    cloud1.render(this.ctx);

    cloud2.render(this.ctx);
}

simpleEngine.run();