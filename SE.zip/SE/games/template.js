

const simpleEngine = new SimpleEngine('gameCanvas');

simpleEngine.init = function() {

}

simpleEngine.update = function(dt) {

}

simpleEngine.render = function() {
    simpleEngine.background("gray");
}

simpleEngine.run();