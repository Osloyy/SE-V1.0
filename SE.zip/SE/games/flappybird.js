

const simpleEngine = new SimpleEngine('gameCanvas');

let player;
let pipe1, pipe2;

const screenh = simpleEngine.canvas.height;

simpleEngine.init = function() {
    player = new Player(60, 300, 20, 20, "yellow");
    player.grav = 200;
    player.jumpForce = 900;
    resetPipes();
}

resetPipes = function() {
    pipe1Height = Math.random() * (screenh - 100);
    pipe2Height = Math.random() * (screenh - pipe1Height - 100);

    pipe1 = new GameObject(900, 0, 30, pipe1Height, "green");
    pipe1.speed = 300;
    pipe2 = new GameObject(900, screenh - pipe2Height, 30, pipe2Height, "green");
    pipe2.speed = 300;
}   

resetPlayerPosition = function() {
    player.x = 60;
    player.y = 300;
}

simpleEngine.update = function(dt) {
    
    if (player.y + player.h > simpleEngine.canvas.height) {
        resetPlayerPosition();
        resetPipes();
    } else if (player.y < 0) {
        resetPlayerPosition();
        resetPipes();
    }
    if (simpleEngine.keys.isDown["M1"]) {
        player.y -= player.jumpForce * dt;
    }

    if (simpleEngine.isColliding(player, pipe1)) {
        resetPlayerPosition();
        resetPipes();
    }else if (simpleEngine.isColliding(player, pipe2)) {
        resetPlayerPosition();
        resetPipes();
    }

    player.y += player.grav * dt;

    pipe1.x -= pipe1.speed * dt;
    pipe2.x -= pipe2.speed * dt;
    
    if (pipe1.x < 0 || pipe2.x < 0) {
        resetPipes();
    }
    
}

simpleEngine.render = function() {
    simpleEngine.background("#32b3bf");
    player.render(this.ctx);
    pipe1.render(this.ctx);
    pipe2.render(this.ctx);
}

simpleEngine.run();