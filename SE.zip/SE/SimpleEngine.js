

class SimpleEngine {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId); 
        this.ctx = this.canvas.getContext("2d");
        this.gameObjects = [];
        this.lastTime = 0;
        this.firstFrame = true;
        this.keys = {
            isDown: {},
            isToggle: {},
        };

        this.levels = {};
        this.currentLevelName = '';
        this.setupKeyboard();
        this.setupMouse();
        this.errorLogCounts = {};
        this.fps = 120;
        this.frameCount = 0;
        this.totalFrameTime = 0;
        this.gameLoop();
    }

    gameLoop(timestamp) {
        
        if (this.firstFrame) {
            this.dt = 0;
            this.firstFrame = false;
        } else {
            if (timestamp > this.lastTime) {
                this.dt = (timestamp - this.lastTime) / 1000;
            }
             else {
                this.dt = 0;
            }
        }


        this.lastTime = timestamp;
        
        this.background("black");

        const currentLevel = this.getCurrentLevel();
        if (currentLevel) {
            this.background(currentLevel.backgroundColor);
        }

        this.update(this.dt);
        this.render();
        requestAnimationFrame(this.gameLoop.bind(this));
    }

    init() {
        this.currentLevelName = 'level1';
    }

    update() {
        
        for (const gameObject of this.gameObjects) {
            if (!gameObject.destroy) {
                gameObject.update(this.keys, this.dt);
            }
        }
        this.checkCollision();
    }

    render() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        for (const gameObject of this.gameObjects) {
            if (!gameObject.destroy) {
                gameObject.render(this.ctx);
            }
        }
        
    }

    addObject(gameObject) {
        this.gameObjects.push(gameObject);
    }


    background(color) {
        this.ctx.fillStyle = color;
        this.ctx.fillRect(0,0,this.canvas.width, this.canvas.height);
    }

    setupKeyboard() {
        window.addEventListener("keydown", (event) => {
            if (event.key === " ") {
                this.keys.isDown["Space"] = true;
            } else {
                this.keys.isDown[event.key] = true;
            }
        });

        window.addEventListener("keyup", (event) => {
            if (event.key === " ") {
                this.keys.isDown["Space"] = false;
            } else {
                this.keys.isDown[event.key] = false;
            }
            this.keys.isToggle[event.key] = !this.keys.isToggle[event.key];
        });
    }

    setupMouse() {
        this.canvas.addEventListener("mousedown", (event) => {
            if (event.button === 0) {
                this.keys.isDown["M1"] = true;
            } else if (event.button === 2) {
                this.keys.isDown["M2"] = true;
            }
        });

        this.canvas.addEventListener("mouseup", (event) => {
            if (event.button === 0) {
                this.keys.isDown["M1"] = false;
                this.keys.isToggle["M1"] = !this.keys.isToggle["M1"];
            } else if (event.button === 2) {
                this.keys.isDown["M2"] = false;
                this.keys.isToggle[event.button] = !this.keys.isToggle["M1"];
            }
        });

        this.canvas.addEventListener("contextmenu", (event) => {
            event.preventDefault();
        });

        this.setupMousePosition();
    }

    setupMousePosition() {
        this.mouse = {
            x: 0,
            y: 0
        };

        this.canvas.addEventListener("mousemove", (event) => {
            const rect = this.canvas.getBoundingClientRect();
            this.mouse.x = event.clientX - rect.left;
            this.mouse.y = event.clientY - rect.top;
        });
    }

    checkCollision() {

        for (let i = 0; i < this.gameObjects.length; i++) {
            const objA = this.gameObjects[i];

            for (let j = i + 1; j < this.gameObjects.length; j++) {
                const objB = this.gameObjects[j];

                if (this.isColliding(objA, objB)) {

                }
            }
        }
    }

    isColliding(objA, objB) {
        const {x: x1, y: y1, w: w1, h: h1} = objA;
        const {x: x2, y: y2, w: w2, h: h2} = objB;
        
        return (
            x1 < x2 + w2 &&
            x1 + w1 > x2 &&
            y1 < y2 + h2 &&
            y1 + h1 > y2
        );
    }

    createLevel(levelName, backgroundColor, gameObjects) {
        this.levels[levelName] = {
            backgroundColor: backgroundColor,
            gameObjects: gameObjects,
        };
    }

    getCurrentLevel() {
        return this.levels[this.currentLevelName];
    }

    switchToLevel(levelName) {
        const level = this.levels[levelName];
        if (level) {
            this.currentLevelName = levelName;
            this.createLevel(level.levelName, level.backgroundColor, level.gameObjects);
            this.gameObjects = [];

            for (const gameObject of level.gameObjects) {
                this.addObject(gameObject);
                gameObject.render(this.ctx);
            }
        }
    }

    initConsole() {
        this.consoleElement = document.getElementById("cw");

        window.onerror = (message, source, lineno, colno, error) => {
            const errorMessage = `Error: ${message}\nSource: ${source}\nLine: ${lineno}\nColumn: ${colno}\nError Object: ${error ? error.stack || error : 'N/A'}`;
            this.logToConsole(errorMessage);
        };
    }

    updateFPS(dt) {
        this.totalFrameTime += dt;
        this.frameCount++;

        if (this.totalFrameTime >= 1) {
            this.fps = this.fps;
            console.log("FPS: " + Math.round(this.fps));
            this.totalFrameTime = 0;
            this.frameCount = 0;

        }
    }

    setDynamicFPS(fps) {
        this.fps = fps;
        console.log("FPS: " + Math.round(this.fps));
    }

    logToConsole(message) {
        this.consoleElement.innerHTML += `<p>[+] - Log: ${message}</p>`;
    }

    warnToConsole(message) {
        this.consoleElement.innerHTML += `<p class=" warning">[-] - Warning: ${message}</p>`;
    }

    handleVisibilityChange() {
        if (document.hidden || !document.hasFocus) {

        }else {
            this.gameLoop();
        }
    }

    run() {
        document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
        this.init();
        this.gameLoop();
    }
}

class GameImage {
    constructor(src, frameWidth, frameHeight, numFrames) {
        this.image = new Image();
        this.image.src = src;
        this.loaded = false;
        this.frameWidth = frameWidth;
        this.frameHeight = frameHeight;
        this.numFrames = numFrames;
        this.frameIndex = 0;

        this.image.onload = () => {
            this.loaded = true;
        };
    }

    getCurrentFrame() {
        const frameX = this.frameIndex * this.frameWidth;
        return {
            x: frameX,
            y: 0,
            width: this.frameWidth,
            height: this.frameHeight
        };
    }

    updateFrameIndex() {
        this.frameIndex = (this.frameIndex + 1) % this.numFrames;
    }
}

class SpriteSheet {
    constructor(src, frameWidth, frameHeight, frameCount, frameRate) {
        this.image = new Image();
        this.image.src = src;
        this.frameWidth = frameWidth;
        this.frameHeight = frameHeight;
        this.frameCount = frameCount;
        this.frameRate = frameRate;
        this.currentFrame = 0;
        this.currentTime = 0;
        this.image.onload = () => {
            this.loaded = true;
        }
       this.update();
       this.isPlaying = true;
      }
    play() {
        this.isPlaying = true;
    }
    pause() {
        this.isPlaying = false;
    }
    update(dt) {
        if (this.loaded && this.isPlaying) {
            this.currentFrame += dt * 1000;

            if (this.currentTime >= 1000 / this.frameRate) {
            this.currentFrame = (this.currentFrame + 1) % this.frameCount;
            this.currentTime -= 1000 / this.frameRate;

            }
        }
        requestAnimationFrame(() => this.update(dt));
    }
    render(ctx, x, y) {
        ctx.clearRect(x, y, this.frameWidth, this.frameHeight);
        ctx.drawImage(
            this.image,
            this.currentFrame * this.frameWidth,
            0,
            this.frameWidth,
            this.frameHeight,
            x,
            y,
            this.frameWidth,
            this.frameHeight
        );
    }
}

class GameObject {
    constructor(x = 10, y = 10, w = 10, h = 10, cOrImage = "white", r = 0, oX = w / 2, oY = h / 2) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.r = r;
        this.oX = oX;
        this.oY = oY;
        this.color = typeof cOrImage === 'string' ? cOrImage : null;
        this.image = typeof cOrImage === 'string' ? null : cOrImage;
        this.destroy = false;
    }
    
    update(dt) {

    }

    render(ctx) {
        ctx.save();
        ctx.translate(this.x + this.oX, this.y + this.oY);
        
        ctx.rotate(this.r);
        
        if (this.color) {
            ctx.fillStyle = this.color;
            ctx.fillRect(-this.w / 2, -this.h / 2, this.w, this.h);
        }else if (this.image) {
            ctx.drawImage(this.image, -this.w / 2, -this.h / 2, this.w, this.h);
        }

        ctx.restore();
    }

}

class TextObject extends GameObject {
    constructor(x = 10, y = 10, text = "Test", font = "12px Arial", c = "white", r = 0, oX = 0, oY = 0) {
        super(x, y, text, font, c, r, oX, oY);
        this.x = x;
        this.y = y;
        this.c = c;
        this.text = text;
        this.font = font;
        this.r = r;
        this.oX = oX;
        this.oY = oY;
        this.destroy = false;
    }

    update(dt) {

    }

    render(ctx) {

        const metrics = ctx.measureText(this.text);
        const textWidth = metrics.width;
        const textHeight = parseInt(this.font, 10);

        ctx.save();
        ctx.font = this.font;
        ctx.fillStyle = this.c;
        ctx.translate(this.x, this.y);
        ctx.rotate(this.r);
        ctx.fillText(this.text, -textWidth / 2, textHeight / 2);
        ctx.restore();
    }
}

class Player extends GameObject {
    constructor(x = 10, y = 10, w = 10, h = 10, cOrImage = "white", r = 0, oX = GameObject.oX, oY = GameObject.oY ) {
        super(x, y, w, h, r, oX, oY);
        this.color = typeof cOrImage === 'string' ? cOrImage : null;
        this.image = typeof cOrImage === 'string' ? null : cOrImage;
        this.destroy = false;
        this.flipX = false;
        this.flipY = false;
        this.isGrounded = false;
        this.isJumping = false;
    }

    update(dt) {
       
    }

    render(ctx) {
        ctx.save();
        ctx.translate(this.x + this.oX, this.y + this.oY);
        ctx.rotate(this.r);
        
        if (this.flipX) {
            ctx.scale(-1, 1);
        }

        if (this.flipY) {
            ctx.scale(1, -1);
        }

        if (this.color) {
            ctx.fillStyle = this.color;
            ctx.fillRect(-this.w / 2, -this.h / 2, this.w, this.h);
        } else if (this.image) {
            if (this.image instanceof GameImage) {
                const frame = this.image.getCurrentFrame();
                ctx.drawImage(this.image.image, frame.x, frame.y, frame.width, frame.height, -this.w / 2, -this.h / 2, this.w, this.h);
                this.image.updateFrameIndex();
            } else {
                ctx.drawImage(this.image, -this.w / 2, -this.h / 2, this.w, this.h);
            }
        }
        
        ctx.restore();
    }

}


class Platform extends GameObject {
    constructor(x, y, w, h, cOrImage, r, oX, oY) {
        super(x, y, w, h, r, oX, oY);
        this.color = typeof cOrImage === 'string' ? cOrImage : null;
        this.image = typeof cOrImage === 'string' ? null : cOrImage;
        this.destroy = false;
    }

    update(dt) {

    }

    render(ctx) {

        ctx.save();
        ctx.translate(this.x + this.oX, this.y + this.oY);
        ctx.rotate(this.r);

        if (this.color) {
            ctx.fillStyle = this.color;
            ctx.fillRect(-this.w / 2, -this.h / 2, this.w, this.h);
        } else if (this.image) {
            ctx.drawImage(this.image, -this.w / 2, -this.h / 2, this.w, this.h);
        }

        ctx.restore();
    }
    
}

class Bullet extends GameObject {
    constructor(x, y, w, h, c, r, oX, oY) {
        super(x, y, w, h, r, oX, oY);
        this.color = c;
        this.destroy = false;
        this.speed = 0;
        this.r = 0;
        this.dx = 0;
        this.dy = 0;
        this.hasFired = false;
    }

    updateRotation(targetX, targetY) {
        const deltaX = targetX - this.x;
        const deltaY = targetY - this.y;
        this.r = Math.atan2(deltaY, deltaX);
        this.calculateDirection();
    }

    calculateDirection() {
        const directionX = Math.cos(this.r);
        const directionY = Math.sin(this.r);
        const magnitude = Math.sqrt(directionX ** 2 + directionY ** 2);

        this.dx = directionX / magnitude * this.speed;
        this.dy = directionY / magnitude * this.speed;
    }

    update(dt) {
        this.x += this.dx * dt;
        this.y += this.dy * dt;
    }
    render(ctx) {
        ctx.save();
        ctx.translate(this.x + this.w / 2, this.y + this.h / 2);
        ctx.rotate(this.r);
        ctx.fillStyle = this.color;
        ctx.fillRect(-this.w / 2, -this.h / 2, this.w, this.h);
        ctx.restore();
    }
}
